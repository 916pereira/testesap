
package com.sap.config;

import com.sap.service.CustomUserDetailsService;
import com.sap.service.GitHubOAuth2UserService;
import com.sap.service.GoogleOAuth2UserService;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler;

import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Value("${app.frontend.url}")
    private String frontendUrl;

    @Value("${COOKIE_SAME_SITE:Lax}")
    private String cookieSameSite;

    @Value("${COOKIE_SECURE:false}")
    private boolean cookieSecure;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider(
            CustomUserDetailsService customUserDetailsService,
            PasswordEncoder passwordEncoder) {

        DaoAuthenticationProvider authenticationProvider =
                new DaoAuthenticationProvider(customUserDetailsService);

        authenticationProvider.setPasswordEncoder(passwordEncoder);

        return authenticationProvider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http,
            DaoAuthenticationProvider authenticationProvider,
            GitHubOAuth2UserService gitHubOAuth2UserService,
            GoogleOAuth2UserService googleOAuth2UserService)
            throws Exception {

        http
                .authenticationProvider(authenticationProvider)

                .cors(cors -> {
                })

                .csrf(csrf -> csrf
                        .csrfTokenRepository(csrfTokenRepository())
                        .csrfTokenRequestHandler(
                                new CsrfTokenRequestAttributeHandler()
                        )

                        .ignoringRequestMatchers(
                                "/api/auth/login",
                                "/api/auth/cadastro",
                                "/api/auth/esqueci-senha"
                        )

                )

                .exceptionHandling(exceptions -> exceptions
                        .defaultAuthenticationEntryPointFor(
                                (request, response, authException) -> {
                                    response.setStatus(
                                            HttpServletResponse.SC_UNAUTHORIZED
                                    );
                                    response.setContentType(
                                            MediaType.APPLICATION_JSON_VALUE
                                    );
                                    response.setCharacterEncoding(
                                            StandardCharsets.UTF_8.name()
                                    );
                                    response.getWriter().write(
                                            "{\"erro\":\"Usuário não autenticado.\"}"
                                    );
                                },
                                request -> request.getServletPath()
                                        .startsWith("/api/")
                        )
                )

                .oauth2Login(oauth -> oauth
                        .userInfoEndpoint(userInfo -> userInfo
                                .userService(gitHubOAuth2UserService)
                                .oidcUserService(googleOAuth2UserService)
                        )

                        .defaultSuccessUrl(
                                frontendUrl,
                                true
                        )

                        .failureHandler((request, response, exception) -> {

                            String mensagem =
                                    "Não foi possível realizar o login.";

                            String codigoErro = null;

                                if (exception
                                        instanceof OAuth2AuthenticationException oauthException) {

                                codigoErro =
                                        oauthException
                                                .getError()
                                                .getErrorCode();
                                }

                                System.err.println("OAUTH_DIAGNOSTICO: tipo=" + exception.getClass().getSimpleName() + " codigo=" + codigoErro);

                                if (exception.getCause() != null) {
                                System.err.println("OAUTH_CAUSA: " + exception.getCause().getClass().getSimpleName());
                                }

                                if ("usuario_inativo".equals(codigoErro)) {

                                mensagem =
                                        "Esta conta está inativa. Entre em contato com o suporte.";

                            } else {

                                String detalhe =
                                        exception.getMessage();

                                if (detalhe != null) {

                                    String detalheNormalizado =
                                            detalhe.toLowerCase();

                                    if (detalheNormalizado.contains(
                                            "já existe uma conta cadastrada com este e-mail"
                                    )) {

                                        mensagem =
                                                "Não foi possível realizar o login. "
                                                + "Este e-mail já está vinculado a outra forma de login.";

                                    } else if (detalheNormalizado.contains(
                                            "não foi possível obter um e-mail válido"
                                    )) {

                                        mensagem =
                                                "Não foi possível realizar o login. "
                                                + "Não foi possível obter um e-mail válido da sua conta.";
                                    }
                                }
                            }

                            String mensagemCodificada =
                                    URLEncoder.encode(
                                            mensagem,
                                            StandardCharsets.UTF_8
                                    );

                            response.sendRedirect(
        frontendUrl + "/?oauthError="
                + mensagemCodificada
);
                        })
                )

                .authorizeHttpRequests(auth -> auth

                .requestMatchers(
                        "/api/auth/csrf",
                        "/api/auth/cadastro",
                        "/api/auth/login",
                        "/api/auth/esqueci-senha",
                        "/api/auth/redefinir-senha",
                        "/oauth2/**",
                        "/login/oauth2/**"
                )
                .permitAll()


                        .requestMatchers(
                                "/api/auth/me",
                                "/api/auth/logout"
                        )
                        .authenticated()

                        .requestMatchers(
                                HttpMethod.GET,
                                "/api/cursos",
                                "/api/ofertas-disciplinas",
                                "/api/disciplinas/**",
                                "/api/assuntos/**",
                                "/api/avaliacoes",
                                "/api/livros/**"
                        )
                        .hasAnyRole(
                                "ESTUDANTE",
                                "PROFESSOR"
                        )

                        .requestMatchers("/api/questoes/professor/**")
                        .hasRole("PROFESSOR")

                        .requestMatchers(
                                "/api/questoes/**",
                                "/api/avaliacoes/finalizar",
                                "/api/analises/**",
                                "/api/resultados",
                                "/api/resultados/**",
                                "/api/configuracao-academica",
                                "/api/configuracao-academica/**",
                                "/api/notificacoes",
                                "/api/notificacoes/**",
                                "/api/preferencias-notificacoes",
                                "/api/preferencias-notificacoes/**",
                                "/api/plano-estudos",
                                "/api/plano-estudos/**"
                        )
                        .hasRole("ESTUDANTE")

                        .requestMatchers("/api/admin/**")
                        .hasRole("ADMIN")

                        .anyRequest()
                        .authenticated()
                );

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration authenticationConfiguration)
            throws Exception {

        return authenticationConfiguration
                .getAuthenticationManager();
    }

    private CookieCsrfTokenRepository csrfTokenRepository() {
        CookieCsrfTokenRepository repository =
                CookieCsrfTokenRepository.withHttpOnlyFalse();

        repository.setCookieCustomizer(cookie -> cookie
                .httpOnly(false)
                .path("/")
                .sameSite(cookieSameSite)
                .secure(cookieSecure)
        );

        return repository;
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration configuration = new CorsConfiguration();

        configuration.setAllowedOrigins(
        List.of(frontendUrl)
);

        configuration.setAllowedMethods(
                List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
        );

        configuration.setAllowedHeaders(
                List.of(
                        "Authorization",
                        "Content-Type",
                        "Accept",
                        "X-XSRF-TOKEN"
                )
        );

        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source =
                new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration("/**", configuration);

        return source;
    }
}
