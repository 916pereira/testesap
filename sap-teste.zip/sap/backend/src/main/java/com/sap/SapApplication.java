package com.sap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@SpringBootApplication
public class SapApplication {

	public static void main(String[] args) {
		loadEnvFile();
		SpringApplication.run(SapApplication.class, args);
	}

	private static void loadEnvFile() {
		List<Path> candidates = List.of(
				Path.of(".env"),
				Path.of("../.env"),
				Path.of("backend/.env")
		);

		for (Path candidate : candidates) {
			Path file = candidate.toAbsolutePath().normalize();
			if (!Files.isRegularFile(file)) {
				continue;
			}

			try {
				for (String line : Files.readAllLines(file)) {
					applyEnvLine(line);
				}
			} catch (IOException e) {
				throw new IllegalStateException("Failed to read " + file, e);
			}

			return;
		}
	}

	private static void applyEnvLine(String line) {
		String text = line.trim();
		if (text.isEmpty() || text.startsWith("#")) {
			return;
		}

		if (text.startsWith("export ")) {
			text = text.substring("export ".length()).trim();
		}

		int separator = text.indexOf('=');
		if (separator <= 0) {
			return;
		}

		String key = text.substring(0, separator).trim();
		String value = text.substring(separator + 1).trim();

		if ((value.startsWith("\"") && value.endsWith("\""))
				|| (value.startsWith("'") && value.endsWith("'"))) {
			value = value.substring(1, value.length() - 1);
		}

		if (key.isEmpty() || System.getenv(key) != null) {
			return;
		}

		System.setProperty(key, value);
	}

}
