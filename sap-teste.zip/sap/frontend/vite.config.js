import react from '@vitejs/plugin-react'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { defineConfig, loadEnv } from 'vite'

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, rootDir, '')
  const apiUrl = env.APP_PUBLIC_API_URL || 'http://localhost:8080'

  return {
    envDir: rootDir,
    plugins: [react()],
    server: {
      proxy: {
        '/api': {
          target: apiUrl,
          changeOrigin: true,
        },
        '/oauth2': {
          target: apiUrl,
          changeOrigin: true,
        },
        '/login': {
          target: apiUrl,
          changeOrigin: true,
        },
      },
    },
  }
})
